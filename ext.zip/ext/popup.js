console.log("Popup JS Loaded");

const countdownIntervals = {};

function sanitizeDomain(input) {
  if (!input) return "";
  input = input.trim().toLowerCase();
  input = input.replace(/^https?:\/\//, "");
  return input.split("/")[0];
}

// ========================================
// Countdown Renderer
// ========================================
function startCountdown(entry) {
  const id = entry.domain;
  const el = document.getElementById(`time_${id}`);

  // If the DOM is not ready yet → retry
  if (!el) {
    setTimeout(() => startCountdown(entry), 100);
    return;
  }

  // clear old interval
  if (countdownIntervals[id]) {
    clearInterval(countdownIntervals[id]);
  }

  function update() {
    const t = entry.unlockAt - Date.now();
    if (t <= 0) {
      el.textContent = "⏳ unlocking soon...";
      return;
    }

    const h = Math.floor(t / 3600000);
    const m = Math.floor((t % 3600000) / 60000);
    const s = Math.floor((t % 60000) / 1000);

    el.textContent = `⏳ unblocks in ${h}h ${m}m ${s}s`;
  }

  update();
  countdownIntervals[id] = setInterval(update, 1000);
}

//**********************************************/
// Load Blocked List (MAIN UI LOGIC)
//*********************************************/
async function loadBlockedList() {
  const { blockedSites = [], pendingUnblocks = [] } =
    await chrome.storage.local.get(["blockedSites", "pendingUnblocks"]);

  const ul = document.getElementById("blockedList");
  ul.innerHTML = "";

  blockedSites.forEach(site => {
    const domain = site.domain;
    const pending = pendingUnblocks.find(x => x.domain === domain);

    const li = document.createElement("li");
    li.className = "site-item";

    // ROW 1: Domain + Button
    const row = document.createElement("div");
    row.className = "row";

    const domainEl = document.createElement("span");
    domainEl.className = "domain";
    domainEl.textContent = domain;

    const btn = document.createElement("button");
    btn.textContent = pending ? "Cancel" : "Unblock";
    btn.className = pending ? "cancel-btn" : "action-btn";

    btn.onclick = () =>
      pending ? cancelUnblock(domain) : requestUnblock(domain);

    row.appendChild(domainEl);
    row.appendChild(btn);
    li.appendChild(row);

    // ROW 2: Countdown (ONLY when pending)
    if (pending) {
      const cd = document.createElement("div");
      cd.className = "countdown";
      cd.id = `time_${domain}`;
      cd.textContent = "⏳ calculating...";
      li.appendChild(cd);

      // Start countdown
      setTimeout(() => startCountdown(pending), 50);
    }

    ul.appendChild(li);
  });
}

//**********************************/
// BLOCK SITE
//*********************************/
async function blockSite() {
  const input = document.getElementById("siteInput");
  const domain = sanitizeDomain(input.value);
  if (!domain) return;

  const { blockedSites = [] } = await chrome.storage.local.get("blockedSites");

  if (blockedSites.some(x => x.domain === domain)) {
    alert("Already blocked.");
    return;
  }

  const ruleId = Math.floor(Math.random() * 2147483647);

  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [{
      id: ruleId,
      priority: 1,
      action: { type: "block" },
      condition: { urlFilter: domain, resourceTypes: ["main_frame"] }
    }]
  });

  blockedSites.push({ domain, ruleId });
  await chrome.storage.local.set({ blockedSites });

  input.value = "";
  loadBlockedList();
}

// ****************************************
// UNBLOCK (start 24h countdown)
// ****************************************
async function requestUnblock(domain) {
  const { blockedSites = [], pendingUnblocks = [] } =
    await chrome.storage.local.get(["blockedSites", "pendingUnblocks"]);

  if (!blockedSites.some(x => x.domain === domain)) return;

  if (pendingUnblocks.some(x => x.domain === domain)) return;

  const entry = blockedSites.find(x => x.domain === domain);

  pendingUnblocks.push({
    domain,
    ruleId: entry.ruleId,
    unlockAt: Date.now() + 86400000 // 24 HOURS
  });

  await chrome.storage.local.set({ pendingUnblocks });
  loadBlockedList();
}

//****************************************/
// CANCEL UNBLOCK
//****************************************/
async function cancelUnblock(domain) {
  const { pendingUnblocks = [] } =
    await chrome.storage.local.get(["pendingUnblocks"]);

  const newList = pendingUnblocks.filter(x => x.domain !== domain);
  await chrome.storage.local.set({ pendingUnblocks: newList });

  if (countdownIntervals[domain]) {
    clearInterval(countdownIntervals[domain]);
    delete countdownIntervals[domain];
  }

  loadBlockedList();
}

// *******************
// INIT
// *******************
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("blockBtn").onclick = blockSite;
  loadBlockedList();
});
