// Ensure the alarm exists
console.log("Background SW loaded");
function createUnblockAlarm() {
  chrome.alarms.create("checkUnblocks", { periodInMinutes: 1 });
}

chrome.runtime.onInstalled.addListener(() => {
  createUnblockAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  createUnblockAlarm();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "checkUnblocks") return;

  const now = Date.now();
  const { blockedSites = [], pendingUnblocks = [] } = await chrome.storage.local.get([
    "blockedSites",
    "pendingUnblocks"
  ]);

  if (!pendingUnblocks.length) return;

  const due = pendingUnblocks.filter(p => now >= p.unlockAt);
  if (!due.length) return;

  const remainingPending = pendingUnblocks.filter(p => now < p.unlockAt);

  const ruleIdsToRemove = due.map(d => d.ruleId);
  const remainingBlocked = blockedSites.filter(
    b => !ruleIdsToRemove.includes(b.ruleId)
  );

  if (ruleIdsToRemove.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: ruleIdsToRemove
    });
  }

  await chrome.storage.local.set({
    blockedSites: remainingBlocked,
    pendingUnblocks: remainingPending
  });

  console.log("Unblocked sites:", due.map(d => d.domain));
});
self.onmessage = () => console.log("SW alive!");
